__name__ = "constallation_mmr"
__version__ = "1.0.0b"
__author__ = "Coulter Stutz"
__email__ = "coulterstutz@constallation.wiki"
from .rig import *
__all__ = ["Rig", "fetch_rigs"]