# Constallation-MMR
An OOP-heavy wrapper for the Mining Rig Rentals API